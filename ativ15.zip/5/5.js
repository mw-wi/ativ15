let soma=0;

for (let index = 0; index < 10; index++) {
    let n=parseFloat(prompt("digite um numero:"));
         soma=soma+n;
}
alert("soma="+ soma);