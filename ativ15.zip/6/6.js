let soma=0;

for (let index = 0; index < 20; index++) {
    let n=parseFloat(prompt("digite sua idade:"));
         soma=soma+n;
}
alert("soma="+ soma);