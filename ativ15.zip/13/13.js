let cont=0;

for (let index = 0; index < 20; index++) {
    let n=parseFloat(prompt("digite um numero:"));
       if (n>0 && n<100){
       cont++
       }
}
alert(cont);
