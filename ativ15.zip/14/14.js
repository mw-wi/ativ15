let cont=0;
let cont1=0;
let cont2=0;

for (let index = 0; index < 20; index++) {
    let n=parseFloat(prompt("digite um numero:"));
       if (n>0 && n<100){
       cont++

       }else if (n>101 && n<200){
        cont1++

        }else if (n>200){
            cont2++
            }
}
alert("entre 0 e 100: "+ cont);
alert("entre 101 e 200: "+ cont1);
alert("entre 101 e 200: "+ cont2);