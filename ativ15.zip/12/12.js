let cont=0;

for (let index = 0; index < 20; index++) {
    let n=parseFloat(prompt("digite um numero:"));
       if (n%2==0){
       cont++
       }
}
alert(cont);