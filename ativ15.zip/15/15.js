let soma=0;
while (true){
    let n=parseFloat(prompt("digite um numero:"));

    if (n>0){
        S=soma+=n
    }else if (n<0){
        break
    }

}
alert(S)

