let ndmv = ""
let idmv = 10000000000

for (let i = 1; i <= 10; i++) {
    let nome = prompt("Digite seu nome: ");
    let idade = prompt("Digite sua idade: ");
    idade = parseFloat(idade);
    
    if(idade<idmv){
        idmv = idade
        ndmv= nome
    }
}
alert("O mais novo é: "+ndmv);