let n = (prompt("digite seu nome:"));
for (let index = 0; index < 10; index++) {
   alert("seu nome é:"+ n);
    
}