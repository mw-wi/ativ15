let soma = 0;
for (let index = 1; index < 15; index++) {
    soma+=index;
    alert("soma="+soma);
    
}