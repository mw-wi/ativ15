let nome=(prompt("digite um nome:"));
let n=(prompt("digite um numero:"));
for (let index = 0; index < n; index++) {
   alert(nome);
    
}