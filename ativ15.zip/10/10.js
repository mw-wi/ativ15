let n = 0;
let al=parseFloat(prompt("digite um numero:"));
for (let index = 0; index <= 10; index++) {
    n=al*index;
    alert(n);
}
